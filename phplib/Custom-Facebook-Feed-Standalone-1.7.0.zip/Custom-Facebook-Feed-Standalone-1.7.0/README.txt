
================== Custom Facebook Feed Standalone ===================

Author: Smash Balloon
Support Website: http://smashballoon.com/custom-facebook-feed/support
Version: 1.7.0
License: Non-distributable, not for resale


================ How to use the Custom Facebook Feed =================

Open the 'demo.php' file for step-by-step instructions on how to set
up and configure your feed.

For more detailed instructions please visit the documentation section
of the Smash Balloon website:
http://smashballoon.com/custom-facebook-feed/docs/standalone


======================= Troubleshooting Notes ========================

1. The page that you're trying to dispay the feed on must be a PHP
   page with a .php extension.  If you are using HTML pages then
   change the file of extension of that page from .html to .php.

2. If you're displayed the message: 'Please enable either cURL or
   allow_url_fopen in your server php.ini file.' then this means that
   neither PHP function required to retrieve the feed from Facebook is
   enabled on your web server. Both of these functions can be enabled
   in your web server's php.ini file. If you are not able to do this
   yourself then simply contact your web hosting provider who will be
   able to assist you.


For further support, please use the form at:
http://smashballoon.com/custom-facebook-feed/support